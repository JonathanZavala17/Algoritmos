#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>
#include <math.h>

GLuint texture[0];

//Definimos variables
double rotate_y=0;
double rotate_x=0;
double rotate_z=0;


float w=0;
float h=0;
float w1=0;
float h1=0;
 


GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;
 
 
GLint ancho = 800;
GLint alto = 600;
int perpectiva = 0;
 
 
 

 void reshape(int w, int h)
 {
	 glViewport(0, 0,(GLsizei) w,(GLsizei) h);
	 glMatrixMode(GL_PROJECTION);
	 glLoadIdentity();
	/* if(perpectiva)
	   gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.2f, 30.0f);
	
	 else*/
	 //glOrtho(-4,4,-4,4,-4,4);
	 glOrtho(-170 ,100,-100,150,-170,170);
	 //glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
	 glMatrixMode(GL_MODELVIEW);
	 
	 ancho = w;
	 alto = h;
 }


void Estadio()
{
    //  Borrar pantalla y Z-buffer
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    //glColor3f(0.0,1.0,1.0);
    // Resetear transformaciones
    glLoadIdentity();
    gluLookAt (4, 2, 3, 0, 0, 0, 0.0,1.0,0.0);
    glScalef (1.0, 2.0, 1.0);
   // gluLookAt (4, 2, 3, 0, 0, 0, 0.0,1.0,0.0);
    // Rotar en el eje X,Y y Z
    glRotatef( rotate_x, 1.0, 0.0, 0.0 );
    glRotatef( rotate_y, 0.0, 1.0, 0.0 );
    glRotatef( rotate_z, 0.0, 0.0, 1.0 );
    glTranslatef(X, Y, Z); 	// Transladar en los 3 ejes
    // Otras transformaciones
    glScalef(scale, scale, scale);
    // Primera cara, se identica por multiples colores
     glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    
    
    
    
    
    
    
    
    
    

    
    
    
    
   
//## Contornos de la cancha ###############################################################################
	
	glColor3f(0.0,1.0,0.0);
	glBegin(GL_QUADS);
	glVertex3f(-65.0f,0.0f,-5.0f);	
	glVertex3f(65.0f,0.0f,-5.0f);
	glVertex3f(65.0f,0.0f,95.0f);
	glVertex3f(-65.0f,0.0f,95.0f);		
	glEnd();


       
	texture[7] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "a.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color3[] = { 0.43f, 0.43f, 0.43f, 0.43f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color3);
        glBindTexture(GL_TEXTURE_2D, texture[1]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);

	
	//CANCHA
	glBegin(GL_QUADS);
	glTexCoord3f(-65.0f,0.2f,-5.0f); glVertex3f(65.0f,0.2f,-5.0f);
	glTexCoord3f(-65.0f,0.2f,-5.0f); glVertex3f(-65.0f,0.2f,-5.0f);
	glTexCoord3f(-65.0f,0.2f,95.0f); glVertex3f(-65.0f,0.2f,95.0f);
	glTexCoord3f(65.0f,0.2f,95.0f); glVertex3f(65.0f,0.2f,95.0f);
	glEnd();
	
	

	//CONTORNO FUERA DEL CAMPO 
	glColor3f(0.0,0.6,0.0);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,-0.1f,-15.0f);	
	glVertex3f(75.0f,-0.1f,-15.0f);
	glVertex3f(75.0f,-0.1f,105.0f);
	glVertex3f(-75.0f,-0.1f,105.0f);		
	glEnd();
   
    //LINEAS DE LA CANCHA
	
	glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,90.0f);	
	glVertex3f(60.0f,0.3f,90.0f);
	glVertex3f(60.0f,0.3f,83.0f);
	glVertex3f(-60.0f,0.3f,83.0f);		
	glEnd();
    
    glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,76.0f);	
	glVertex3f(60.0f,0.3f,76.0f);
	glVertex3f(60.0f,0.3f,69.0f);
	glVertex3f(-60.0f,0.3f,69.0f);		
	glEnd();
    
	glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,62.0f);	
	glVertex3f(60.0f,0.3f,62.0f);
	glVertex3f(60.0f,0.3f,55.0f);
	glVertex3f(-60.0f,0.3f,55.0f);		
	glEnd();
   
    glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,41.0f);	
	glVertex3f(60.0f,0.3f,41.0f);
	glVertex3f(60.0f,0.3f,48.0f);
	glVertex3f(-60.0f,0.3f,48.0f);		
	glEnd();
   
    glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,34.0f);	
	glVertex3f(60.0f,0.3f,34.0f);
	glVertex3f(60.0f,0.3f,27.0f);
	glVertex3f(-60.0f,0.3f,27.0f);		
	glEnd();
 
	glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,20.0f);	
	glVertex3f(60.0f,0.3f,20.0f);
	glVertex3f(60.0f,0.3f,13.0f);
	glVertex3f(-60.0f,0.3f,13.0f);			
	glEnd();
   
	glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,6.0f);	
	glVertex3f(60.0f,0.3f,6.0f);
	glVertex3f(60.0f,0.3f,0.0f);
	glVertex3f(-60.0f,0.3f,0.0f);			
	glEnd();
     
	glBegin(GL_QUADS);
	glVertex3f(-60.0f,0.3f,6.0f);	
	glVertex3f(-53.0f,0.3f,6.0f);
	glVertex3f(-53.0f,0.3f,0.0f);
	glVertex3f(-60.0f,0.3f,0.0f);			
	glEnd();


	
	
	//pasillo inferior derecho
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,-0.1f,-15.0f);	
	glVertex3f(75.0f,-0.1f,-15.0f);
	glVertex3f(75.0f,-0.1f,-20.0f);
	glVertex3f(-75.0f,-0.1f,-20.0f);		
	glEnd();
	
	//tope del pasillo inferior derecho
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,-0.1f,-15.0f);	
	glVertex3f(-75.0f,5.0f,-15.0f);
	glVertex3f(-75.0f,5.0f,-24.8f);
	glVertex3f(-75.0f,-0.1f,-20.0f);		
	glEnd();
	
	//pasillo inferior izquierdo
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,5.0f,105.0f);	
	glVertex3f(-80.0f,5.0f,105.0f);
	glVertex3f(-80.0f,5.0f,-24.8f);
	glVertex3f(-75.0f,5.0f,-24.8f);		
	glEnd();
	
	//Suelo Cian de la izquierda
	glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-120.0f,-0.2f,105.0f);
	glVertex3f(-120.0f,-0.2f,-15.0f);
	glVertex3f(-75.0f,-0.20f,-15.0f);
	glVertex3f(-75.0f,-0.20,105.0f);
	glEnd();

	//Suelo completo
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-120.0f,-0.21f,105.0f);
	glVertex3f(-120.0f,-0.21f,-60.0f);
	glVertex3f(75.0f,-0.21f,-60.0f);
	glVertex3f(75.0f,-0.21,105.0f);
	glEnd();





//## Techo #################################################################################################################################
	
	


	glColor3f(0.43,0.43,0.43);
       
	texture[1] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "20.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color2[] = { 0.43f, 0.43f, 0.43f, 0.43f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color2);
        glBindTexture(GL_TEXTURE_2D, texture[1]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);

	
	
	//Techo derecho
	glBegin(GL_QUADS);
	glTexCoord3f(75.0f,47.5f,-20.0f); glVertex3f(75.0f,47.5f,-20.0f);
	glTexCoord3f(75.0f,44.0f,-70.0f); glVertex3f(75.0f,44.0f,-70.0f);
	glTexCoord3f(-130.0f,44.0f,-70.0f); glVertex3f(-130.0f,44.0f,-70.0f);
	glTexCoord3f(-80.0f,47.5f,-20.0f); glVertex3f(-80.0f,47.5f,-20.0f);
	glEnd();
	
	
	//Techo izquierdo
	glBegin(GL_QUADS);
	glTexCoord3f(-80.0f,47.5f,105.0f); glVertex3f(-80.0f,47.5f,105.0f);
	glTexCoord3f(-130.0f,44.0f,105.0f); glVertex3f(-130.0f,44.0f,105.0f);
	glTexCoord3f(-130.0f,44.0f,-70.0f); glVertex3f(-130.0f,44.0f,-70.0f);
	glTexCoord3f(-80.0f,47.5f,-20.0f); glVertex3f(-80.0f,47.5f,-20.0f);
	glEnd();


	    
    
	
//############### Barandales #################################################################################################################################
	
	
	
	
	//Baranda superior izquierda
	
	glBegin(GL_QUADS);
	glColor3f(0.0,0.0,0.89);
	glVertex3f(-105.0f,22.5f,105.0f);
	glVertex3f(-105.0f,23.5f,105.0f);
	glVertex3f(-105.0f,23.5f,-45.0f);
	glVertex3f(-105.0f,22.5f,-45.0f);
	glEnd();
	
	//Baranda superior derecho
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(75.0f,22.5f,-45.0f);
	glVertex3f(75.0f,23.5f,-45.0f);
	glVertex3f(-105.0f,23.5f,-45.0f);
	glVertex3f(-105.0f,22.5,-45.0f);
	glEnd();
	

	//Baranda alta
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(-120.0f,29.5f,105.0f);
	glVertex3f(-120.0f,32.5f,105.0f);
	glVertex3f(-120.0f,32.5f,-60.0f);
	glVertex3f(-120.0f,29.5f,-60.0f);
	glEnd();
	
	//Baranda alta
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(75.0f,29.5f,-60.0f);
	glVertex3f(75.0f,32.5f,-60.0f);
	glVertex3f(-120.0f,32.5f,-60.0f);
	glVertex3f(-120.0f,29.5,-60.0f);
	glEnd();
	
	//Barandas superiores
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(-100.0f,24.5f,105.0f);
	glVertex3f(-100.0f,22.5f,105.0f);
	glVertex3f(-100.0f,22.5f,-40.0f);
	glVertex3f(-100.0f,24.5f,-40.0f);
	
	glVertex3f(-100.0f,24.5f,-40.0f);
	glVertex3f(-100.0f,22.5f,-40.0f);
	glVertex3f(75.0f,22.5f,-40.0f);
	glVertex3f(75.0f,24.5f,-40.0f);
	glEnd();
	
	//Altura del barandal izquerdo
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,5.0f,105.0f);
	glVertex3f(-75.0f,6.0f,105.0f);
	glVertex3f(-75.0f,6.0f,-24.8f);
	glVertex3f(-75.0f,5.0f,-24.8f);
	glEnd();
	
	
	//VALLAS izquierda inferior 
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,-0.1f,0.0f);	
	glVertex3f(-75.0f,-0.1f,90.0f);
	glVertex3f(-75.0f,5.0f,90.0f);
	glVertex3f(-75.0f,5.0f,0.0f);		
	glEnd();

	//VALLAS derecha inferior 
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(-75.0f,-0.1f,-15.0f);	
	glVertex3f(75.0f,-0.1f,-15.0f);
	glVertex3f(75.0f,2.0f,-15.0f);
	glVertex3f(-75.0f,2.0f,-15.0f);		
	glEnd();
	
	
	 
	//Altura del barandal derecho
	glColor3f(0.0,0.0,0.89);
	glBegin(GL_QUADS);
	glVertex3f(75.0f,-0.1f,-20.0f);
	glVertex3f(75.0f,1.51f,-20.0f);
	glVertex3f(-75.0f,1.5f,-20.0f);
	glVertex3f(-75.0f,-0.1,-20.0f);
	glEnd();

    

//### Gradas #############################################################################################################################################################
	
	glColor3f(1.0,1.0,1.0);
       
	texture[1] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "gradas.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color1[] = { 1.0f, 1.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color1);
        glBindTexture(GL_TEXTURE_2D, texture[1]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);


	//Gradas izquierdas
	
	glBegin(GL_POLYGON);
	glTexCoord3f(-95.0f,12.5f,105.0f); glVertex3f(-95.0f,12.5f,105.0f);
	glTexCoord3f(-80.0f,5.0f,105.0f); glVertex3f(-80.0f,5.0f,105.0f);
	glTexCoord3f(-80.0f,5.0f,-24.8f); glVertex3f(-80.0f,5.0f,-24.8f);
	glTexCoord3f(-95.0f,12.5f,-35.0f); glVertex3f(-95.0f,12.5f,-35.0f);
	glEnd();
	
	
	 //Gradas Derechas
	
	glBegin(GL_QUADS);
	glTexCoord3f(95.0f,12.5f,-35.0f); glVertex3f(95.0f,12.5f,-35.0f);
	glTexCoord3f(80.0f,1.5f,-20.0f); glVertex3f(80.0f,1.5f,-20.0f);
	glTexCoord3f(-80.0f,1.5f,-20.0f); glVertex3f(-80.0f,1.5f,-20.0f);
	glTexCoord3f(-95.0f,12.5,-35.0f);glVertex3f(-95.0f,12.5,-35.0f);
	glEnd();
	 
	//Gradas Derechas superiores
	
	glBegin(GL_QUADS);
	glTexCoord3f(75.0f,29.5f,-60.0f); glVertex3f(120.0f,29.5f,-60.0f);
	glTexCoord3f(75.0f,22.5f,-45.0f);glVertex3f(105.0f,22.5f,-45.0f);
	glTexCoord3f(-105.0f,22.5f,-45.0f); glVertex3f(-105.0f,22.5f,-45.0f);
	glTexCoord3f(-120.0f,29.5,-60.0f); glVertex3f(-120.0f,29.5,-60.0f);
	glEnd();
	
	
	//Gradas izquierdas superiores
	
	glBegin(GL_POLYGON);
	glTexCoord3f(-120.0f,29.5f,105.0f); glVertex3f(-120.0f,29.5f,105.0f);
	glTexCoord3f(-105.0f,22.5f,105.0f); glVertex3f(-105.0f,22.5f,105.0f);
	glTexCoord3f(-105.0f,22.5f,-45.0f); glVertex3f(-105.0f,22.5f,-45.0f);
	glTexCoord3f(-120.0f,29.5f,-60.0f); glVertex3f(-120.0f,29.5f,-60.0f);
	glEnd();
	
	
	
	//Gradas izquierdas
	
	glBegin(GL_POLYGON);
	glTexCoord3f(95.0f,12.5f,105.0f); glVertex3f(95.0f,12.5f,105.0f);
	glTexCoord3f(80.0f,1.5f,105.0f); glVertex3f(80.0f,1.5f,105.0f);
	glTexCoord3f(80.0f,1.5f,-24.8f); glVertex3f(80.0f,1.5f,-24.8f);
	glTexCoord3f(95.0f,12.5f,-35.0f); glVertex3f(95.0f,12.5f,-35.0f);
	glEnd();
	
	
	 //Gradas Derechas
	
	glBegin(GL_QUADS);
	glTexCoord3f(75.0f,12.5f,-35.0f); glVertex3f(75.0f,12.5f,-35.0f);
	glTexCoord3f(75.0f,1.5f,-20.0f); glVertex3f(75.0f,1.5f,-20.0f);
	glTexCoord3f(-80.0f,1.5f,-20.0f); glVertex3f(-80.0f,1.5f,-20.0f);
	glTexCoord3f(-95.0f,12.5,-35.0f);glVertex3f(-95.0f,12.5,-35.0f);
	glEnd();
	 
	//Gradas Derechas superiores
	
	glBegin(GL_QUADS);
	glTexCoord3f(75.0f,29.5f,-60.0f); glVertex3f(75.0f,29.5f,-60.0f);
	glTexCoord3f(75.0f,22.5f,-45.0f);glVertex3f(75.0f,22.5f,-45.0f);
	glTexCoord3f(-105.0f,22.5f,-45.0f); glVertex3f(-105.0f,22.5f,-45.0f);
	glTexCoord3f(-120.0f,29.5,-60.0f); glVertex3f(-120.0f,29.5,-60.0f);
	glEnd();
	
	
	//Gradas izquierdas superiores
	
	glBegin(GL_POLYGON);
	glTexCoord3f(120.0f,29.5f,105.0f); glVertex3f(120.0f,29.5f,105.0f);
	glTexCoord3f(105.0f,22.5f,105.0f); glVertex3f(105.0f,22.5f,105.0f);
	glTexCoord3f(105.0f,22.5f,-45.0f); glVertex3f(105.0f,22.5f,-45.0f);
	glTexCoord3f(120.0f,29.5f,-60.0f); glVertex3f(120.0f,29.5f,-60.0f);
	glEnd();
	
    
    //Lineas
    glPushMatrix();
    glColor3f(1,1,1);	
	glLineWidth(2.5);
	glBegin(GL_LINES);
	glVertex3f(-60.0f,0.2f,0.0f);
	glVertex3f(60.0f,0.2f,0.0f);
	glVertex3f(60.0f,0.2f,0.0f);
	glVertex3f(60.0f,0.2f,90.0f);
	glVertex3f(60.0f,0.2f,90.0f);
	glVertex3f(-60.0f,0.2f,90.0f);
	glVertex3f(-60.0f,0.2f,90.0f);
	glVertex3f(-60.0f,0.2f,0.0f);
	glEnd();
	glPopMatrix();
	glPopMatrix();
    glEnd();
	
	
	//penal primero
	glPointSize(2);
	  glBegin(GL_POINTS);
		glVertex3f(44.0F,0.4f,45.0f);
	glEnd();
	
	//penal segundo
	  glBegin(GL_POINTS);
		glVertex3f(-44.0F,0.4f,45.0f);
	glEnd();
	
	//centro
	glPointSize(2);
		glBegin(GL_POINTS);
		glVertex3f(0.0F,0.4f,45.0f);
	glEnd();
   
   
    //Area peque;a y grande
    glPushMatrix();
    glColor3f(1,1,1);	
	glLineWidth(3.5);
	glBegin(GL_LINES);
	glVertex3f(60.0f,0.4f,40.34f);
	glVertex3f(60.0f,2.46f,40.34f);
	glVertex3f(60.0f,2.46f,40.34f);
	glVertex3f(60.0f,2.46f,49.66f);
	glVertex3f(60.0f,2.46f,49.66f);
	glVertex3f(60.0f,0.2f,49.66f);
	glVertex3f(-60.0f,0.2f,40.34f);
	glVertex3f(-60.0f,2.46f,40.34f);
	glVertex3f(-60.0f,2.46f,40.34f);
	glVertex3f(-60.0f,2.46f,49.66f);
	glVertex3f(-60.0f,2.46f,49.66f);
	glVertex3f(-60.0f,0.4f,49.66f);
	
	glVertex3f(60.0f,0.4f,33.0f);
	glVertex3f(50.0f,0.4f,33.0f);
	glVertex3f(50.0f,0.4f,33.0f);
	glVertex3f(50.0f,0.4f,57.0f);
	glVertex3f(50.0f,0.4f,57.0f);
	glVertex3f(60.0f,0.4f,57.0f);
	glVertex3f(-60.0f,0.4f,33.0f);
	glVertex3f(-50.0f,0.4f,33.0f);
	glVertex3f(-50.0f,0.4f,33.0f);
	glVertex3f(-50.0f,0.4f,57.0f);
	glVertex3f(-50.0f,0.4f,57.0f);
	glVertex3f(-60.0f,0.4f,57.0f);
	
	glVertex3f(60.0f,0.4f,22.0f);
	glVertex3f(39.0f,0.4f,22.0f);
	glVertex3f(39.0f,0.4f,22.0f);
	glVertex3f(39.0f,0.4f,68.0f);
	glVertex3f(39.0f,0.4f,68.0f);
	glVertex3f(60.0f,0.4f,68.0f);
	glVertex3f(-60.0f,0.4f,22.0f);
	glVertex3f(-39.0f,0.4f,22.0f);
	glVertex3f(-39.0f,0.4f,22.0f);
	glVertex3f(-39.0f,0.4f,68.0f);
	glVertex3f(-39.0f,0.4f,68.0f);
	glVertex3f(-60.0f,0.4f,68.0f);
	
	
	glVertex3f(0.0f,0.4f,90.0f);
	glVertex3f(0.0f,0.4f,0.0f);
	
	
	
	
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
	
	 //Centro del estadio
   GLfloat punto_x=0;
   GLfloat punto_y=45;
    
    double i,cx,cy;
    int radiox=11.5;
    int radioy=11.5;
    
    glPointSize(2);
    glBegin(GL_POINTS);
    for (i=0;i<=8; i+=0.01)
    {
		cx=radiox*cos(i) + punto_x;
		cy=radiox*sin(i) + punto_y;
		glVertex3f(cx,0.4,cy);
	}
	 glEnd();
	
	glPopMatrix();
    
    glPushMatrix();
	//media luna1
	GLfloat punto_x1=44.0;
   GLfloat punto_y1=45.0;
    
    double n,cx1,cy1;
    double radiox1=11.5;
    double radioy1=11.5;
    
    glPointSize(2);
    glBegin(GL_POINTS);
    for (n=2.0;n<=4.2; n+=0.01)
    {
		cx1=radiox1*cos(n) + punto_x1;
		cy1=radiox1*sin(n) + punto_y1;
		glVertex3f(cx1,0.4,cy1);
	}
	 glEnd();
	glPopMatrix();
	
	//media luna2
	GLfloat punto_x2=-44.0;
   GLfloat punto_y2=45;
    
    double k,cx2,cy2;
    double radiox2=11.5;
    double radioy2=11.5;
    
    glPointSize(2);
    glBegin(GL_POINTS);
    for (k=-1.1;k<=1.1; k+=0.01)
    {
		cx2=radiox2*cos(k) + punto_x2;
		cy2=radiox2*sin(k) + punto_y2;
		glVertex3f(cx2,0.4,cy2);
	}
	 glEnd();

//## Soportes del techo y pantalla #######################################################################################################################
	
    
	
	//Soportes de pantalla
	
	glLineWidth(3.5);
	glBegin(GL_LINES);
	glVertex3f(-120.6f,42.5f,45.0f);
	glVertex3f(-120.6f,29.0f,45.0f);
	glVertex3f(-120.6f,29.0f,10.0f);
	glVertex3f(-120.6f,42.5f,10.0f);
	glEnd();
	


	//Soportes
	glLineWidth(10);
	glBegin(GL_LINES);
	glColor3f(1.0,1.0,1.0);	
	glVertex3f(70.0f,43.5f,-65.5f);
	glVertex3f(70.0f,-0.1f,-65.5f);
	glVertex3f(40.0f,43.5f,-65.5f);
	glVertex3f(40.0f,-0.1f,-65.5f);
	glVertex3f(10.0f,43.5f,-65.5f);
	glVertex3f(10.0f,-0.1f,-65.5f);
	glVertex3f(-20.0f,43.5f,-65.5f);
	glVertex3f(-20.0f,-0.1f,-65.5f);
	glVertex3f(-50.0f,43.5f,-65.5f);
	glVertex3f(-50.0f,-0.1f,-65.5f);
	glVertex3f(-80.0f,43.5f,-65.5f);
	glVertex3f(-80.0f,-0.1f,-65.5f);
	
	
	
	glVertex3f(-125.0f,43.5f,100.0f);
	glVertex3f(-125.0f,-0.1f,100.0f);
	glVertex3f(-125.0f,43.5f,70.0f);
	glVertex3f(-125.0f,-0.1f,70.0f);
	glVertex3f(-125.0f,43.5f,40.0f);
	glVertex3f(-125.0f,-0.1f,40.0f);
	glVertex3f(-125.0f,43.5f,10.0f);
	glVertex3f(-125.0f,-0.1f,10.0f);
	glVertex3f(-125.0f,43.5f,-20.0f);
	glVertex3f(-125.0f,-0.1f,-20.0f);
	

	//Dos circulares
	glVertex3f(-110.0f,43.0f,-65.5f);
	glVertex3f(-110.0f,-0.1f,-65.5f);
	
	glVertex3f(-125.0f,43.0f,-50.0f);
	glVertex3f(-125.0f,-0.1f,-50.0f);
	
	
	glEnd();



	//Vigas derechas
	glLineWidth(10);
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(68.0f,47.0f,-20.0f);
	glVertex3f(68.0f,44.0f,-67.0f);
	glVertex3f(68.0f,43.0f,-67.0f);
	glVertex3f(72.0f,43.0f,-67.0f);
	glVertex3f(72.0f,44.0f,-67.0f);
	glVertex3f(72.0f,47.0f,-20.5f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(38.0f,47.0f,-20.0f);
	glVertex3f(38.0f,44.0f,-67.0f);
	glVertex3f(38.0f,43.0f,-67.0f);
	glVertex3f(42.0f,43.0f,-67.0f);
	glVertex3f(42.0f,44.0f,-67.0f);
	glVertex3f(42.0f,47.0f,-20.5f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(8.0f,47.0f,-20.0f);
	glVertex3f(8.0f,44.0f,-67.0f);
	glVertex3f(8.0f,43.0f,-67.0f);
	glVertex3f(12.0f,43.0f,-67.0f);
	glVertex3f(12.0f,44.0f,-67.0f);
	glVertex3f(12.0f,47.0f,-20.5f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-18.0f,47.0f,-20.0f);
	glVertex3f(-18.0f,44.0f,-67.0f);
	glVertex3f(-18.0f,43.0f,-67.0f);
	glVertex3f(-22.0f,43.0f,-67.0f);
	glVertex3f(-22.0f,44.0f,-67.0f);
	glVertex3f(-22.0f,47.0f,-20.5f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-48.0f,47.0f,-20.0f);
	glVertex3f(-48.0f,44.0f,-67.0f);
	glVertex3f(-48.0f,43.0f,-67.0f);
	glVertex3f(-52.0f,43.0f,-67.0f);
	glVertex3f(-52.0f,44.0f,-67.0f);
	glVertex3f(-52.0f,47.0f,-20.5f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-78.0f,47.0f,-20.0f);
	glVertex3f(-78.0f,44.0f,-67.0f);
	glVertex3f(-78.0f,43.0f,-67.0f);
	glVertex3f(-82.0f,43.0f,-67.0f);
	glVertex3f(-82.0f,44.0f,-67.0f);
	glVertex3f(-82.0f,47.0f,-20.5f);
	
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-85.0f,47.0f,-20.0f);
	glVertex3f(-108.0f,44.0f,-67.0f);
	glVertex3f(-108.0f,43.0f,-67.0f);
	glVertex3f(-112.0f,43.0f,-67.0f);
	glVertex3f(-112.0f,44.0f,-67.0f);
	glVertex3f(-85.0f,47.0f,-20.5f);
	
	glEnd();
	
	
	
	//Izquierdos
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-80.0f,47.0f,102.0f);
	glVertex3f(-127.0f,44.0f,102.0f);
	glVertex3f(-127.0f,43.0f,102.0f);
	glVertex3f(-127.0f,43.0f,98.0f);
	glVertex3f(-127.0f,44.0f,98.0f);
	glVertex3f(-80.0f,47.0f,98.0f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-80.0f,47.0f,72.0f);
	glVertex3f(-127.0f,44.0f,72.0f);
	glVertex3f(-127.0f,43.0f,72.0f);
	glVertex3f(-127.0f,43.0f,68.0f);
	glVertex3f(-127.0f,44.0f,68.0f);
	glVertex3f(-80.0f,47.0f,68.0f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-80.0f,47.0f,42.0f);
	glVertex3f(-127.0f,44.0f,42.0f);
	glVertex3f(-127.0f,43.0f,42.0f);
	glVertex3f(-127.0f,43.0f,38.0f);
	glVertex3f(-127.0f,44.0f,38.0f);
	glVertex3f(-80.0f,47.0f,38.0f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-80.0f,47.0f,12.0f);
	glVertex3f(-127.0f,44.0f,12.0f);
	glVertex3f(-127.0f,43.0f,12.0f);
	glVertex3f(-127.0f,43.0f,8.0f);
	glVertex3f(-127.0f,44.0f,8.0f);
	glVertex3f(-80.0f,47.0f,8.0f);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-80.0f,47.0f,-18.0f);
	glVertex3f(-127.0f,44.0f,-18.0f);
	glVertex3f(-127.0f,43.0f,-18.0f);
	glVertex3f(-127.0f,43.0f,-22.0f);
	glVertex3f(-127.0f,44.0f,-22.0f);
	glVertex3f(-80.0f,47.0f,-22.0f);
	glEnd();
	
	
	glBegin(GL_POLYGON);
	glColor3f(0.43,0.43,0.43);	
	glVertex3f(-80.0f,47.0f,-25.0f);
	glVertex3f(-127.0f,44.0f,-48.0f);
	glVertex3f(-127.0f,43.0f,-48.0f);
	glVertex3f(-127.0f,43.0f,-52.0f);
	glVertex3f(-127.0f,44.0f,-52.0f);
	glVertex3f(-80.0f,47.0f,-25.0f);
	glEnd();
    
  
    //###########################
  
  
  
    //Pantalla

	glColor3f(1.0,1.0,1.0);
       
	texture[8] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "17.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color10[] = { 1.0f, 1.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color10);
        glBindTexture(GL_TEXTURE_2D, texture[8]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);


	glBegin(GL_QUADS);
		
	glTexCoord3f(-120.0f,42.5f,45.0f); glVertex3f(-120.0f,42.5f,45.0f);
	glTexCoord3f(-120.0f,33.5f,45.0f); glVertex3f(-120.0f,33.5f,45.0f);
	glTexCoord3f(-120.0f,33.5f,10.0f); glVertex3f(-120.0f,33.5f,10.0f);
	glTexCoord3f(-120.0f,42.5f,10.0f); glVertex3f(-120.0f,42.5f,10.0f);
	
	glEnd();
	
	
	
	
//############## Paredes trasera ##############################################################################################################################



    glColor3f(1.0,1.0,1.0);
       
	texture[8] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "fuera.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color5[] = { 1.0f, 1.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color5);
        glBindTexture(GL_TEXTURE_2D, texture[8]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);


	//Pared trasera derecha
	
	glBegin(GL_POLYGON);
	glTexCoord3f(75.0f,29.5,-60.1f); glVertex3f(75.0f,29.5,-60.1f);
	glTexCoord3f(-120.0f,29.5f,-60.1f); glVertex3f(-120.0f,29.5f,-60.1f);
	glTexCoord3f(-120.0f,17.5f,-60.1f); glVertex3f(-120.0f,-0.1f,-60.1f);
	glTexCoord3f(75.0f,17.5f,-60.1f); glVertex3f(75.0f,-0.1f,-60.1f);
	glEnd();
	
	//Pared trasera izquierda
	glBegin(GL_POLYGON);
	glTexCoord3f(-120.1f,-0.1f,-60.0f); glVertex3f(-120.1f,-0.1f,-60.0f);
	glTexCoord3f(-120.1f,29.5f,-60.0f); glVertex3f(-120.1f,29.5f,-60.0f);
	glTexCoord3f(-120.1f,29.5f,105.1f); glVertex3f(-120.1f,29.5f,105.1f);
	glTexCoord3f(-120.1f,-0.1f,105.1f); glVertex3f(-120.1f,-0.1f,105.1f);
	glEnd();
	
	
//############## Intermedio ##############################################################################################################################



    glColor3f(1.0,1.0,1.0);
       
	texture[7] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "17.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color4[] = { 1.0f, 1.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color4);
        glBindTexture(GL_TEXTURE_2D, texture[7]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);


	//izquierdo  
	
	glBegin(GL_POLYGON);
	glTexCoord3f(-100.0f,12.5f,105.0f); glVertex3f(-100.0f,12.5f,105.0f);
	glTexCoord3f(-100.0f,22.5f,105.0f); glVertex3f(-100.0f,22.5f,105.0f);
	glTexCoord3f(-100.0f,22.5f,-40.0f); glVertex3f(-100.0f,22.5f,-40.0f);
	glTexCoord3f(-100.0f,12.5f,-40.0f); glVertex3f(-100.0f,12.5f,-40.0f);
	glEnd();
	
	
	//derecho
	glBegin(GL_POLYGON);
    glTexCoord3f(-100.0f,12.5f,-40.0f); glVertex3f(-100.0f,12.5f,-40.0f);
	glTexCoord3f(-100.0f,22.5f,-40.0f); glVertex3f(-100.0f,22.5f,-40.0f);
	glTexCoord3f(105.0f,22.5f,-40.0f); glVertex3f(105.0f,22.5f,-40.0f);
	glTexCoord3f(105.0f,12.5f,-40.0f); glVertex3f(105.0f,12.5f,-40.0f);
	glEnd();
	
	
	
	//paredes izquierdas bajo gradas
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-95.0f,12.5f,90.0f);
	glVertex3f(-120.0f,12.5f,90.0f);
	glVertex3f(-120.0f,-0.1f,90.0f);
	glVertex3f(-95.0f,-0.1f,90.0f);
	glEnd();
    
    
  
	//paredes izquierdas bajo gradas
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-95.0f,12.5f,0.0f);
	glVertex3f(-120.0f,12.5f,0.0f);
	glVertex3f(-120.0f,-0.1f,0.0f);
	glVertex3f(-95.0f,-0.1f,0.0f);
	glEnd();

	
	//paredes izquierdas bajo gradas
	glBegin(GL_QUADS);
	glVertex3f(-95.0f,12.5f,-15.0f);
	glVertex3f(-120.0f,12.5f,-15.0f);
	glVertex3f(-120.0f,-0.1f,-15.0f);
	glVertex3f(-95.0f,-0.1f,-15.0f);
	glEnd();


	//paredes izquierdas bajo gradas
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-95.0f,12.5f,105.0f);
	glVertex3f(-120.0f,12.5f,105.0f);
	glVertex3f(-120.0f,-0.1f,105.0f);
	glVertex3f(-95.0f,-0.1f,105.0f);
	glEnd();
	


//### 	GRISES  ##########################################################################################################################################


	//Pasillo derecha
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-100.0f,12.5f,-40.0f);
	glVertex3f(-100.0f,12.5f,-35.0f);
	glVertex3f(75.0f,12.5f,-35.0f);
	glVertex3f(75.0f,12.5f,-40.0f);
	glEnd();

		
	//Pasillo izquierda
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-95.0f,12.5f,105.0f);
	glVertex3f(-100.0f,12.5f,105.0f);
	glVertex3f(-100.0f,12.5f,-40.0f);
	glVertex3f(-95.0f,12.5f,-40.0f);
	glEnd();

	//Pasillo derecho superior
	glColor3f(0.43,0.43,0.43);
	glBegin(GL_QUADS);
	glVertex3f(-105.0f,22.5f,-40.0f);
	glVertex3f(-105.0f,22.5f,-45.0f);
	glVertex3f(75.0f,22.5f,-45.0f);
	glVertex3f(75.0f,22.5f,-40.0f);
	
	//Pasillo izquierda superior
	glVertex3f(-100.0f,22.5f,105.0f);
	glVertex3f(-105.0f,22.5f,105.0f);
	glVertex3f(-105.0f,22.5f,-40.0f);
	glVertex3f(-100.0f,22.5f,-40.0f);
	glEnd();
 
	

//######## Paredes frontales ########################################################################################################################################################3
	
	
       
	texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "fuera.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
     glEnable(GL_TEXTURE_2D);

        float color[] = { 1.0f, 1.0f,1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);
        glBindTexture(GL_TEXTURE_2D, texture[0]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);



    //Tope de baranda derecha
	glBegin(GL_POLYGON);
	glTexCoord3f(75.1f,-0.1,-15.0f); glVertex3f(75.1f,-0.1,-15.0f);
	glTexCoord3f(75.1f,2.0,-15.0f); glVertex3f(75.1f,2.0f,-15.0f);
	glTexCoord3f(75.1f,2.0,-20.0f); glVertex3f(75.1f,2.0f,-20.0f);
	glTexCoord3f(75.1f,14.5,-35.0f); glVertex3f(75.1f,14.5f,-35.0f);
	glTexCoord3f(75.1f,-0.1,-35.0f); glVertex3f(75.1f,-0.1f,-35.0f);
	glEnd();
	
	//Topes de baranda izquierda
	glBegin(GL_POLYGON);
	glTexCoord3f(-74.999f,-0.1,105.2f); glVertex3f(-74.999f,-0.1,105.2f);
	glTexCoord3f(-74.999f,6.0f,105.2f); glVertex3f(-74.999f,6.0f,105.2f);
	glTexCoord3f(-80.0f,6.0f,105.2f); glVertex3f(-80.0f,6.0f,105.2f);
	glTexCoord3f(-95.0f,14.5f,105.2f); glVertex3f(-95.0f,14.5f,105.2f);
	glTexCoord3f(-95.0f,-0.1f,105.2f); glVertex3f(-95.0f,-0.1f,105.2f);
	glEnd();
	
	
	//Topes rectangulares de izquierda y derecha respectivo
	glBegin(GL_QUADS);
	glTexCoord3f(75.11f,-0.1,-35.0f); glVertex3f(75.11f,-0.1,-35.0f);
	glTexCoord3f(75.11f,14.5,-35.0f); glVertex3f(75.11f,14.5f,-35.0f);
	glTexCoord3f(75.11f,14.5,-40.0f); glVertex3f(75.11f,14.5f,-40.0f);
	glTexCoord3f(75.11f,-0.1,-40.0f); glVertex3f(75.11f,0.1f,-40.0f);
	glEnd();
	
	
	glBegin(GL_QUADS);
	glTexCoord3f(-95.0f,-0.1f,105.2f); glVertex3f(-95.0f,-0.1f,105.2f);
	glTexCoord3f(-95.0f,14.5f,105.2f); glVertex3f(-95.0f,14.5f,105.2f);
	glTexCoord3f(-100.0f,14.5f,105.2f); glVertex3f(-100.0f,14.5f,105.2f);
	glTexCoord3f(-100.0f,-0.1f,105.2f); glVertex3f(-100.0f,-0.1f,105.2f);
	glEnd();


	//Topes de baranda izquierda
	glBegin(GL_POLYGON);
	glTexCoord3f(-100.f,-0.1,105.11f);glVertex3f(-100.f,-0.1,105.11f);
	glTexCoord3f(-100.0f,24.5f,105.01f); glVertex3f(-100.0f,24.5f,105.01f);
	glTexCoord3f(-120.0f,32.5f,105.01f); glVertex3f(-120.0f,32.5f,105.01f);
	glTexCoord3f(-120.0f,-0.1f,105.11f); glVertex3f(-120.0f,-0.1f,105.11f);
	glEnd();

    //Tope de baranda derecha
	glBegin(GL_POLYGON);
	glTexCoord3f(75.1f,-0.1,-40.0f); glVertex3f(75.1f,-0.1,-40.0f);
	glTexCoord3f(75.1f,24.5f,-40.0f); glVertex3f(75.1f,24.5f,-40.0f);
	glTexCoord3f(75.1f,32.5f,-60.f); glVertex3f(75.1f,32.5f,-60.f);
	glTexCoord3f(75.1f,-0.1f,-60.0f); glVertex3f(75.1f,-0.1f,-60.0f);
	glEnd();
	
	
	//tope del pasillo inferior izquierdo
	glBegin(GL_QUADS);
	glTexCoord3f(-74.9f,-0.1f,-15.0f); glVertex3f(-74.9f,-0.1f,-15.0f);	
	glTexCoord3f(-74.9f,4.99f,-15.0f); glVertex3f(-74.9f,4.99f,-15.0f);
	glTexCoord3f(-74.9f,4.99f,-23.8f); glVertex3f(-74.9f,4.99f,-23.8f);
	glTexCoord3f(-74.9f,-0.1f,-20.0f); glVertex3f(-74.9f,-0.1f,-20.0f);		
	glEnd();
	
	//1ra pared
	glBegin(GL_POLYGON);
	glTexCoord3f(-75.0f,-0.1f,90.0f); glVertex3f(-75.0f,-0.1f,90.0f);
	glTexCoord3f(-80.0f,-0.1f,90.0f); glVertex3f(-80.0f,-0.1f,90.0f);
	glTexCoord3f(-95.0f,-0.1f,90.0f); glVertex3f(-95.0f,-0.1f,90.0f);
	glTexCoord3f(-95.0f,12.5f,90.0f); glVertex3f(-95.0f,12.5f,90.0f);
	glTexCoord3f(-80.0f,5.0f,90.0f); glVertex3f(-80.0f,5.0f,90.0f);
	glTexCoord3f(-75.0f,5.0f,90.0f); glVertex3f(-75.0f,5.0f,90.0f);
	glEnd();
	
	//2da pared
	glBegin(GL_POLYGON);
	glTexCoord3f(-75.0f,-0.1f,-15.0f); glVertex3f(-75.0f,-0.1f,-15.0f);
	glTexCoord3f(-80.0f,-0.1f,-15.0f); glVertex3f(-80.0f,-0.1f,-15.0f);
	glTexCoord3f(-95.0f,-0.1f,-15.0f); glVertex3f(-95.0f,-0.1f,-15.0f);
	glTexCoord3f(-95.0f,12.5f,-15.0f); glVertex3f(-95.0f,12.5f,-15.0f);
	glTexCoord3f(-80.0f,5.0f,-15.0f); glVertex3f(-80.0f,5.0f,-15.0f);
	glTexCoord3f(-75.0f,5.0f,-15.0f); glVertex3f(-75.0f,5.0f,-15.0f);
	glEnd();
	
	//3ra pared
	glBegin(GL_POLYGON);
	glTexCoord3f(-75.0f,-0.1f,0.0f); glVertex3f(-75.0f,-0.1f,0.0f);
	glTexCoord3f(-80.0f,-0.1f,0.0f); glVertex3f(-80.0f,-0.1f,0.0f);
	glTexCoord3f(-95.0f,-0.1f,0.0f); glVertex3f(-95.0f,-0.1f,0.0f);
	glTexCoord3f(-95.0f,12.5f,0.0f); glVertex3f(-95.0f,12.5f,0.0f);
	glTexCoord3f(-80.0f,5.0f,0.0f); glVertex3f(-80.0f,5.0f,0.0f);
	glTexCoord3f(-75.0f,5.0f,0.0f); glVertex3f(-75.0f,5.0f,0.0f);
	glEnd();
	
	
	
	
	
	
	
	
	
//########  Detalles internos ################################################################################################################

	glBegin(GL_QUADS);
	//Pared trasera inferior izquierda
	glColor3f(0.43,0.43,0.43);
	glVertex3f(-120.0f,12.4f,-60.0f);
	glVertex3f(-95.9f,12.4f,-60.0f);
	glVertex3f(-95.9f,12.4f,105.0f);
	glVertex3f(-120.0f,12.4f,105.0f);
	//Pared 1
	glVertex3f(-120.0f,-0.01f,-60.0f);
	glVertex3f(-120.0f,12.4f,-60.0f);
	glVertex3f(-120.0f,12.4f,-15.0f);
	glVertex3f(-120.0f,-0.1f,-15.0f);
	//Pared 2
	glVertex3f(-120.0f,-0.01f,0.0f);
	glVertex3f(-120.0f,12.4f,0.0f);
	glVertex3f(-120.0f,12.4f,90.0f);
	glVertex3f(-120.0f,-0.1f,90.0f);
	
	//Pared trasera superior izquierda
	glVertex3f(-120.0f,17.51f,-60.0f);
	glVertex3f(-100.0f,17.51f,-60.0f);
	glVertex3f(-100.0f,17.51f,105.0f);
	glVertex3f(-120.0f,17.51f,105.0f);
	//Pared 3
	glVertex3f(-120.0f,17.51f,-60.0f);
	glVertex3f(-120.0f,29.5f,-60.0f);
	glVertex3f(-120.0f,29.5f,105.1f);
	glVertex3f(-120.0f,17.51f,105.1f);

	
	glEnd();
	
	//Derecha
	glBegin(GL_QUADS);
	glVertex3f(75.0f,17.51,-60.0f);
	glVertex3f(-120.0f,17.51f,-60.0f);
	glVertex3f(-120.0f,17.51f,-44.9f);
	glVertex3f(75.0f,17.51f,-44.9f);
	
	//Parte inferior
	glVertex3f(75.0f,12.5,-60.0f);
	glVertex3f(-120.0f,12.5f,-60.0f);
	glVertex3f(-120.0f,12.5f,-40.f);
	glVertex3f(75.0f,12.5f,-40.0f);
	
	//Pared 1
	glVertex3f(75.0f,-0.1,-60.0f);
	glVertex3f(-120.0f,-0.1f,-60.0f);
	glVertex3f(-120.0f,12.5f,-60.0f);
	glVertex3f(75.0f,12.5f,-60.0f);
	
	//Pared 2
	glVertex3f(75.0f,29.5,-60.0f);
	glVertex3f(-120.0f,29.5f,-60.0f);
	glVertex3f(-120.0f,17.5f,-60.0f);
	glVertex3f(75.0f,17.5f,-60.0f);
	
	glEnd();


	//Pared completa
	glBegin(GL_QUADS);

	glVertex3f(75.0f,29.5,-60.00001f);
	glVertex3f(-120.0f,29.5f,-60.00001f);
	glVertex3f(-120.0f,-0.1f,-60.00001f);
	glVertex3f(75.0f,-0.1f,-60.00001f);

	glVertex3f(-120.00001f,-0.1f,-60.0f);
	glVertex3f(-120.00001f,29.5f,-60.0f);
	glVertex3f(-120.00001f,29.5f,105.1f);
	glVertex3f(-120.00001f,-0.1f,105.1f);

	
	glEnd();


    
    glFlush();
    glutSwapBuffers();
 
}


void display()
{
    //  Borrar pantalla y Z-buffer
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
 
    // Resetear transformaciones
    glLoadIdentity();
    
    
    
    Estadio();

	

    
    glFlush();
    glutSwapBuffers();
 
}
 
 
// Función para controlar teclas especiales
void specialKeys( int key, int x, int y )
{
 
    //  Flecha derecha: aumentar rotación 7 grados
    if (key == GLUT_KEY_RIGHT)
        rotate_y += 7;
 
    //  Flecha izquierda: rotación en eje Y negativo 7 grados
    else if (key == GLUT_KEY_LEFT)
        rotate_y -= 7;
    //  Flecha arriba: rotación en eje X positivo 7 grados
    else if (key == GLUT_KEY_UP)
        rotate_x += 7;
    //  Flecha abajo: rotación en eje X negativo 7 grados
    else if (key == GLUT_KEY_DOWN)
        rotate_x -= 7;
    //  Tecla especial F2 : rotación en eje Z positivo 7 grados
    else if (key == GLUT_KEY_F2)
        rotate_z += 7;
    //  Tecla especial F2 : rotación en eje Z negativo 7 grados
    else if (key == GLUT_KEY_F1)
        rotate_z -= 7;
 
    //  Solicitar actualización de visualización
    glutPostRedisplay();
 
}
 
// Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
    switch (key)
    {
    case 's':
        scale=0.5;
        break;
    case 'd':
        scale=1.5;
        break;
    case 'x' :
        X += 0.1f;
        break;
    case 'X' :
        X -= 0.1f;
        break;
    case 'y' :
        Y += 0.1f;
        break;
    case 'Y' :
        Y -= 0.1f;
        break;
    case 'z':
        Z -= 0.1f;
        break;
    case 'Z':
        Z += 0.1f;
        break;
    case 27:
        exit(0);			// exit
    }
    glutPostRedisplay();
}

 
int main(int argc, char* argv[])
{
 
    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);
 
    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 600);
    glutInitWindowPosition (0, 0);
    // Crear ventana
    
    glutCreateWindow("Old Trafford");
    glutReshapeFunc(reshape);    
    gluLookAt (4, 2, 3, 0, 0, 0, 0.0,1.0,0.0);
    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
    // Funciones de retrollamada
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
	
    // Pasar el control de eventos a GLUT
    glutMainLoop();
 
    // Regresar al sistema operativo
    return 0;
 
}
