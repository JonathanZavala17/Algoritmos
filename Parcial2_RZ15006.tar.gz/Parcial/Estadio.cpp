#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>
 
//Definimos variables
double rotate_y=0;
double rotate_x=0;
double rotate_z=0;
 
GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;
 
GLuint texture[0];
 
GLint ancho = 650;
GLint alto = 650;



//funcion luz
/*
void luz(void)
{
	
	 //ubicamos la fuete de luz
   GLfloat punto_luz[]={-8.0,7.0,0.0};
   GLfloat luz_ambiental[]={0.5,0.5,0.5};
    
    // acitivamos la fuente de luz
     glShadeModel (GL_SMOOTH);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0); //Activamos las luces en 0
    glDepthFunc(GL_LESS); //comparación de profundidad
    glEnable(GL_DEPTH_TEST); //activa GL_DEPTH_TES
   
}*/
void luz2(){
	GLfloat light_position[] = {21.0,4.0, -15.0, 0.0 };
    GLfloat lmodel_ambient [] = { 0.2, 0.2, 0.2, 1.0 };

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0); //Activamos las luces en 0
    glDepthFunc(GL_LESS); //comparación de profundidad
    glEnable(GL_DEPTH_TEST); //activa GL_DEPTH_TEST
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	glLightfv(GL_LIGHT0,GL_POSITION,light_position);

}

unsigned int textureID;  //variable para la textura



void mapeo(){       
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
        //glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);

        //usamos la autogeneración de coordenadas
        GLfloat plano_s[2] = {4, 0}; // s=x
        GLfloat plano_t[2] = {0, 4}; // t=y      
        glTexGeni (GL_S, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
        glTexGenfv (GL_S, GL_NORMAL_MAP, plano_s);
        glTexGeni (GL_T, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
        glTexGenfv (GL_T, GL_NORMAL_MAP, plano_t);   

        glEnable(GL_TEXTURE_2D);
        glEnable (GL_TEXTURE_GEN_T);
        glEnable (GL_TEXTURE_GEN_S);
        
        glEnd();
}


void textura(){
	glPushMatrix();
    texture[1] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "gris.png",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
	//glBindTexture(GL_TEXTURE_2D, texture[1]);
	//define_textura_2D_128(textura_ladrillos);
			                     GLUquadric *quad;
								 quad = gluNewQuadric();
								 gluQuadricTexture(quad, GL_TRUE);
								 glEnable(GL_TEXTURE_2D);
								 glBindTexture(GL_TEXTURE_2D, texture[1]);
								
								//glRotatef(-90,1,0,0);
								//glRotatef(90,0,0,1);
								 
								 
								 
	mapeo();
	//Pared derecha
	glPushMatrix();
    glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,0.0f,-0.5f);	
	glVertex3f(-10.0f,0.0f,16.0f);
	glVertex3f(-10.0f,6.0f,16.0f);
	glVertex3f(-10.0f,6.0f,-0.5f);		
	glEnd();
	glPopMatrix();
	
	
	//Pared derecha
	glPushMatrix();
    glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,-0.5f,-0.5f);	
	glVertex3f(-10.5f,-0.5f,16.0f);
	glVertex3f(-10.5f,6.0f,16.0f);
	glVertex3f(-10.5f,6.0f,-0.5f);		
	glEnd();
	glPopMatrix();
	
	//Pared derecha arriba 
	
	glPushMatrix();
    glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,6.0f,16.0f);	
	glVertex3f(-10.5f,6.0f,-0.5f);
	glVertex3f(-10.0f,6.0f,-0.5f);
	glVertex3f(-10.0f,6.0f,16.0f);		
	glEnd();
	glPopMatrix();
	
	//Pared derecha adelante 
	
	glPushMatrix();
    glColor3f(0.0,1.0,0.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,6.0f,16.0f);	
	glVertex3f(-10.0f,6.0f,16.0f);
	glVertex3f(-10.0f,-0.5f,16.0f);
	glVertex3f(-10.5f,-0.5f,16.0f);		
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(0.0,1.0,0.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,6.0f,-0.5f);	
	glVertex3f(-10.0f,6.0f,-0.5f);
	glVertex3f(-10.0f,-0.5f,-0.5f);
	glVertex3f(-10.5f,-0.5f,-0.5f);		
	glEnd();
	glPopMatrix();
	
	
	
	
	glPushMatrix();
    glColor3f(0.0,1.0,0.0);
	glBegin(GL_QUADS);
	glVertex3f(20.5f,6.0f,16.0f);	
	glVertex3f(20.0f,6.0f,16.0f);
	glVertex3f(20.0f,-0.5f,16.0f);
	glVertex3f(20.5f,-0.5f,16.0f);		
	glEnd();
	glPopMatrix();
	
	
	glPushMatrix();
    glColor3f(0.0,1.0,0.0);
	glBegin(GL_QUADS);
	glVertex3f(20.5f,6.0f,-0.5f);	
	glVertex3f(20.0f,6.0f,-0.5f);
	glVertex3f(20.0f,-0.5f,-0.5f);
	glVertex3f(20.5f,-0.5f,-0.5f);		
	glEnd();
	glPopMatrix();
	
	
	
	
	
	//Izquierda
	//Pared derecha
	glPushMatrix();
    glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(20.0f,0.0f,-0.5f);	
	glVertex3f(20.0f,0.0f,16.0f);
	glVertex3f(20.0f,6.0f,16.0f);
	glVertex3f(20.0f,6.0f,-0.5f);		
	glEnd();
	glPopMatrix();
	
 
 
	//Pared derecha
	glPushMatrix();
    glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(20.5f,-0.5f,-0.5f);	
	glVertex3f(20.5f,-0.5f,16.0f);
	glVertex3f(20.5f,6.0f,16.0f);
	glVertex3f(20.5f,6.0f,-0.5f);		
	glEnd();
	glPopMatrix();
	
	//Pared derecha arriba 
	
	glPushMatrix();
    glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(20.5f,6.0f,16.0f);	
	glVertex3f(20.5f,6.0f,-0.5f);
	glVertex3f(20.0f,6.0f,-0.5f);
	glVertex3f(20.0f,6.0f,16.0f);		
	glEnd();
	glPopMatrix();
	
	
	
	
	
	
	//Gris
	
	//Parte de atras
	glPushMatrix();
    glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,6.0f,0.0f);	
	glVertex3f(-10.0f,-0.5f,0.0f);
	glVertex3f(20.0f,-0.5f,0.0f);
	glVertex3f(20.0f,6.0f,0.0f);		
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,6.0f,-0.5f);	
	glVertex3f(-10.5f,-0.5f,-0.5f);
	glVertex3f(20.5f,-0.5f,-0.5f);
	glVertex3f(20.5f,6.0f,-0.5f);		
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(1.0,0.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,6.0f,0.0f);	
	glVertex3f(-10.5f,6.0f,-0.5f);
	glVertex3f(20.5f,6.0f,-0.5f);
	glVertex3f(20.5f,6.0f,0.0f);		
	glEnd();
	glPopMatrix();
	
	
	
	
	
}
void textura1(){
	 glPushMatrix();
    texture[2] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "benny.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[2]);
	mapeo();
	glTranslatef(0,0,0);
	glPushMatrix();
	
	glTranslatef(2.0, 2.5, 3.0);
    glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(2.0,4.5,10,10);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef (-4.0,2.0,3.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(2.0f,4.5f,10,10);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    
   
    glTranslatef (-4.0,2.5,9.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(1.0f,4.5f,10,10);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef (2.0,2.5,9.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(1.0f,4.5f,10,10);
    glEnd();
    glPopMatrix();
	glPushMatrix();
    glTranslatef (0.5,2.5,15.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(1.0f,4.5f,10,10);
    glEnd();
    glPopMatrix();
 
   glPushMatrix();
    glTranslatef (15,2.5,3.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(2.0f,4.5f,10,10);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef (8.0,1.0,3.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(2.0f,2.5f,10,10);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef (8.0,1.0,11.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(2.0f,2.5f,10,10);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef (17.0,2.5,11.0);
	glRotatef(90.0,-200.0,1.0,0.0);
    glutSolidCone(2.0f,4.5f,10,10);
    glEnd();
    glPopMatrix();
	glPopMatrix();
    glEnd();
	
}
void textura2(){
	 glPushMatrix();
    texture[3] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "verdeoscuro.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[3]);
	mapeo();
		glPushMatrix();
    glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,0.0f,0.0f);	
	glVertex3f(-10.0f,0.0f,16.0f);
	glVertex3f(20.0f,0.0f,16.0f);
	glVertex3f(20.0f,0.0f,0.0f);		
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(0.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.5f,-0.5f,0.0f);	
	glVertex3f(-10.5f,-0.5f,16.0f);
	glVertex3f(20.5f,-0.5f,16.0f);
	glVertex3f(20.5f,-0.5f,0.0f);		
	glEnd();
	glPopMatrix();
	glPushMatrix();
    glColor3f(1.0,1.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,0.3f,0.0f);	
	glVertex3f(-10.0f,0.3f,5.0f);
	glVertex3f(20.0f,0.3f,5.0f);
	glVertex3f(20.0f,0.3f,0.0f);		
	glEnd();
	glPopMatrix();
	
	
}
void textura3(){
	 glPushMatrix();
    texture[4] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "verdeclaro.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[4]);
	mapeo();
	glPushMatrix();
    glColor3f(0.0,1.0,0.69);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,0.0f,16.0f);	
	glVertex3f(-10.0f,-0.5f,16.0f);
	glVertex3f(20.0f,-0.5f,16.0f);
	glVertex3f(20.0f,0.0f,16.0f);		
	glEnd();
	glPopMatrix();
	
}
void textura4(){
	 glPushMatrix();
    texture[5] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "celesteclaro.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[5]);
	mapeo();
	 glPushMatrix();
    glColor3f(0.0,0.0,1.0);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,0.0f,7.0f);	
	glVertex3f(-10.0f,0.3f,7.0f);
	glVertex3f(20.0f,0.3f,7.0f);
	glVertex3f(20.0f,0.0f,7.0f);		
	glEnd();
	glPopMatrix();
	
}

void textura5(){
	 glPushMatrix();
    texture[6] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "celeste.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[6]);
	mapeo();
	glPushMatrix();
    glColor3f(0.0,0.0,0.69);
	glBegin(GL_QUADS);
	glVertex3f(-10.0f,0.3f,5.0f);	
	glVertex3f(-10.0f,0.3f,7.0f);
	glVertex3f(20.0f,0.3f,7.0f);
	glVertex3f(20.0f,0.3f,5.0f);		
	glEnd();
	glPopMatrix();
 
    
}
   
void textura6(){
	 glPushMatrix();
    texture[7] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "naranjaos.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[7]);
	mapeo();
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(2.0, 2.5, 3.0);
	glVertex3f(2.0,0.0,3.0);
	
	glVertex3f(-4.0,2.0,3.0);
	glVertex3f(-4.0f,0.0f,3.0f);
	
	glVertex3f(-4.0,2.5,9.0);
	glVertex3f(-4.0,0.0,9.0);
	
	glVertex3f(2.0,2.5,9.0);
	glVertex3f(2.0,0.0,9.0);
	
	glVertex3f(0.5,2.5,15.0);
	glVertex3f(0.5,0.0,15.0);
	
	glVertex3f(15,2.5,3.0);
	glVertex3f(15,0.0,3.0);
	
	glVertex3f(8.0,1.0,3.0);
	glVertex3f(8.0,0.0,3.0);
	
	glVertex3f(8.0,1.0,11.0);
	glVertex3f(8.0,0.0,11.0);
	
	glVertex3f(17.0,2.5,11.0);
	glVertex3f(17.0,0.0,11.0);
	
	glVertex3f(12.0,1.5,9.5);
	glVertex3f(12.0,0.0,9.5);
    
    
    
    
  
    
	glEnd();
	glPopMatrix();
    glEnd();
}
	
 void textura7(){
	 glPushMatrix();
    texture[8] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "naranja.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
    glBindTexture(GL_TEXTURE_2D, texture[8]);
	mapeo();
	glPushMatrix();
    glTranslatef (12.0,1.5,11.5);
	glRotatef(0.0,0.0,1.0,0.0);
    glutSolidCone(1.5f,2.5f,10,10);
    glEnd();
    glPopMatrix();
	glPopMatrix();
    glEnd();
}



static void display(void)
{
    //  Borrar pantalla y Z-buffer
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   
    // Resetear transformaciones
    glLoadIdentity();
	

	  // Rotar en el eje X,Y y Z
    glRotatef( rotate_x, 1.0, 0.0, 0.0 );
    glRotatef( rotate_y, 0.0, 1.0, 0.0 );
    glRotatef( rotate_z, 0.0, 0.0, 1.0 );
    
    textura();
    textura1();
    textura2();
    textura3();
    textura4();
    textura5();
	textura6();
	textura7();
	
	
	
	
	
	glTranslatef(-4.0 ,0.0, 6.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    glTranslatef(2.0 ,0.0, 6.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    glTranslatef(8.0 ,0.0, 6.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    glTranslatef(14.0 ,0.0, 6.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    
    
    glTranslatef(5.0 ,3.5, 0.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    glTranslatef(12.0 ,3.5, 0.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    glTranslatef(0.0 ,1.5, 3.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    glTranslatef(3.0 ,1.5, 3.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    
    glTranslatef(-17.0 ,0.0, -3.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    glTranslatef(-0.0 ,1.5, 3.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    glTranslatef(0.0 ,-1.5, -3.0);
    glutSolidSphere(1, 20, 200);
	glPopMatrix();
    glEnd();
    
    
    
    
    glDisable(GL_TEXTURE_2D);
	glPopMatrix();
    glEnd();
	
	
    glFlush();
    glutSwapBuffers();
 
}
 
// Función para controlar teclas especiales
void specialKeys( int key, int x, int y )
{
 
    //  Flecha derecha: aumentar rotación 7 grados
    if (key == GLUT_KEY_RIGHT)
        rotate_y += 7;
 
    //  Flecha izquierda: rotación en eje Y negativo 7 grados
    else if (key == GLUT_KEY_LEFT)
        rotate_y -= 7;
    //  Flecha arriba: rotación en eje X positivo 7 grados
    else if (key == GLUT_KEY_UP)
        rotate_x += 7;
    //  Flecha abajo: rotación en eje X negativo 7 grados
    else if (key == GLUT_KEY_DOWN)
        rotate_x -= 7;
    //  Tecla especial F2 : rotación en eje Z positivo 7 grados
    else if (key == GLUT_KEY_INSERT)
        rotate_z += 7;
    //  Tecla especial F2 : rotación en eje Z negativo 7 grados
    else if (key == GLUT_KEY_HOME)
        rotate_z -= 7;
 
    //  Solicitar actualización de visualización
    glutPostRedisplay();
 
}
 


void reshape(int w, int h)
 {
	 glViewport(0, 0,(GLsizei) w,(GLsizei) h);
	 glMatrixMode(GL_PROJECTION);
	 
	 glLoadIdentity();

	 glOrtho(-20.0, 30.0, -20.0, 20.0, -50.0, 50.0);
	 gluLookAt (1.0, 1.0, 3.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.0);
	 glMatrixMode(GL_MODELVIEW);
	 glLoadIdentity();
	 
	 ancho = w;
	 alto = h;
 }
 
int main(int argc, char* argv[])
{
 
    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);
 
    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (650, 650);
    glutInitWindowPosition (200, 0);
    // Crear ventana
    glutCreateWindow("Parcial :'v");
 
    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);
 
    // Funciones de retrollamada
	//luz();
	luz2();
	
    glutReshapeFunc(reshape);
    glutDisplayFunc(display);
    glutSpecialFunc(specialKeys);

    // Pasar el control de eventos a GLUT
    glutMainLoop();
 
    // Regresar al sistema operativo
   // return 0;
 
}


